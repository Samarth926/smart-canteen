-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 20, 2024 at 08:43 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clg_canteen_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `bl_id` int(100) NOT NULL AUTO_INCREMENT,
  `or_id` varchar(100) NOT NULL,
  `bill_amount` varchar(100) NOT NULL,
  `bill_date` varchar(100) NOT NULL,
  `bill_type` varchar(100) NOT NULL,
  PRIMARY KEY (`bl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bl_id`, `or_id`, `bill_amount`, `bill_date`, `bill_type`) VALUES
(1, '1', '100', '2024-8-20', 'online');

-- --------------------------------------------------------

--
-- Table structure for table `canteen_details`
--

DROP TABLE IF EXISTS `canteen_details`;
CREATE TABLE IF NOT EXISTS `canteen_details` (
  `ct_id` int(100) NOT NULL AUTO_INCREMENT,
  `ct_name` varchar(100) NOT NULL,
  `ct_type` varchar(100) NOT NULL,
  `ct_owner` varchar(100) NOT NULL,
  `ct_email` varchar(100) NOT NULL,
  `ct_mobile` varchar(12) NOT NULL,
  `ct_address` varchar(100) NOT NULL,
  `ct_status` varchar(100) NOT NULL,
  `ct_photo1` varchar(100) NOT NULL,
  `ct_photo2` varchar(100) NOT NULL,
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `canteen_details`
--

INSERT INTO `canteen_details` (`ct_id`, `ct_name`, `ct_type`, `ct_owner`, `ct_email`, `ct_mobile`, `ct_address`, `ct_status`, `ct_photo1`, `ct_photo2`) VALUES
(1, 'KLE Canteen', 'Collage', 'Santosh K', 'klecanteen@gmail.com', '9988774455', 'Chikkodi', 'requested', 'user.png', 'noimg.png');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
CREATE TABLE IF NOT EXISTS `complaints` (
  `cm_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `ct_id` varchar(100) NOT NULL,
  `complaints` varchar(100) NOT NULL,
  `cm_date` varchar(100) NOT NULL,
  PRIMARY KEY (`cm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`cm_id`, `u_id`, `ct_id`, `complaints`, `cm_date`) VALUES
(1, '1', '1', 'No Maintaining Cleaness', '2024-8-20');

-- --------------------------------------------------------

--
-- Table structure for table `dish_details`
--

DROP TABLE IF EXISTS `dish_details`;
CREATE TABLE IF NOT EXISTS `dish_details` (
  `d_id` int(100) NOT NULL AUTO_INCREMENT,
  `d_name` varchar(100) NOT NULL,
  `d_type` varchar(100) NOT NULL,
  `d_price` varchar(100) NOT NULL,
  `d_desc` varchar(100) NOT NULL,
  `d_status` varchar(100) NOT NULL,
  `ct_id` varchar(100) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dish_details`
--

INSERT INTO `dish_details` (`d_id`, `d_name`, `d_type`, `d_price`, `d_desc`, `d_status`, `ct_id`) VALUES
(1, 'Veg Thali', 'Veg', '80', '2 Roti, 2 Bhaji and Rice', 'Available', '1'),
(2, 'Pulav', 'Veg', '100', 'Veg Pulav', 'Available', '1'),
(3, 'Egg Biryani', 'Veg', '100', 'Egg Biryani', 'Available', '1');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `u_type` varchar(100) NOT NULL,
  `s_question` varchar(100) NOT NULL,
  `s_answer` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `u_type`, `s_question`, `s_answer`, `status`) VALUES
('admin@pro', 'admin123', 'admin', 'Where did your born?', 'Chikkodi', 'active'),
('klecanteen@gmail.com', '12345', 'canteen', 'Which is your favourite Bike?', 'Ninja', 'active'),
('samarth@gmail.com', '112233', 'user', 'What is your first & Best friend name ?', 'Snehal', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
CREATE TABLE IF NOT EXISTS `notice` (
  `n_id` int(100) NOT NULL AUTO_INCREMENT,
  `n_from` varchar(100) NOT NULL,
  `n_to` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `s_date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`n_id`, `n_from`, `n_to`, `notice`, `s_date`, `status`) VALUES
(1, 'Admin', '1', 'Testing Notice', '2024-8-20', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE IF NOT EXISTS `order_details` (
  `or_id` int(100) NOT NULL AUTO_INCREMENT,
  `or_code` varchar(100) NOT NULL,
  `u_id` varchar(100) NOT NULL,
  `d_id` varchar(100) NOT NULL,
  `or_quantity` varchar(100) NOT NULL,
  `or_date` varchar(100) NOT NULL,
  `u_arriving_time` varchar(100) NOT NULL,
  `or_status` varchar(100) NOT NULL,
  PRIMARY KEY (`or_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`or_id`, `or_code`, `u_id`, `d_id`, `or_quantity`, `or_date`, `u_arriving_time`, `or_status`) VALUES
(1, '445357', '1', '3', '1', '2024-8-20', '02:00 PM', 'Placed');

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

DROP TABLE IF EXISTS `payment_details`;
CREATE TABLE IF NOT EXISTS `payment_details` (
  `py_id` int(100) NOT NULL AUTO_INCREMENT,
  `ac_holder` varchar(100) NOT NULL,
  `upi_id` varchar(100) NOT NULL,
  `upi_pin` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  PRIMARY KEY (`py_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`py_id`, `ac_holder`, `upi_id`, `upi_pin`, `amount`) VALUES
(1, 'klecanteen@gmail.com', 'klecanteen@okaxis', '-', '100'),
(2, 'samarth@gmail.com', 'smrt@oksbi', '1221', '9900');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `r_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `d_id` varchar(100) NOT NULL,
  `review` varchar(100) NOT NULL,
  `rating` varchar(100) NOT NULL,
  `r_date` varchar(100) NOT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
CREATE TABLE IF NOT EXISTS `user_details` (
  `u_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_fname` varchar(100) NOT NULL,
  `u_lname` varchar(100) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_mobile` varchar(12) NOT NULL,
  `u_city` varchar(100) NOT NULL,
  `u_gender` varchar(100) NOT NULL,
  `u_dob` varchar(100) NOT NULL,
  `u_photo` varchar(100) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`u_id`, `u_fname`, `u_lname`, `u_email`, `u_mobile`, `u_city`, `u_gender`, `u_dob`, `u_photo`) VALUES
(1, 'Samarth', 'Patil', 'samarth@gmail.com', '9638527410', 'Chikkodi', 'Male', '2003-06-11', '1707321411.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
